import React from 'react';
import { ShoppingBag, Menu, Search, User, Heart, ShoppingCart } from 'lucide-react';

// Temporary product data
const featuredProducts = [
  {
    id: 1,
    name: 'Classic White T-Shirt',
    price: 29.99,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 2,
    name: 'Denim Jacket',
    price: 89.99,
    image: 'https://images.unsplash.com/photo-1523205771623-e0faa4d2813d?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 3,
    name: 'Black Hoodie',
    price: 59.99,
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 4,
    name: 'Slim Fit Jeans',
    price: 79.99,
    image: 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=800',
  },
];

const categories = [
  { name: 'New Arrivals', image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=800' },
  { name: 'Trending', image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=800' },
  { name: 'Bestsellers', image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80&w=800' },
];

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <button className="p-2 rounded-md hover:bg-gray-100">
                <Menu className="h-6 w-6" />
              </button>
              <div className="ml-4 flex items-center">
                <ShoppingBag className="h-8 w-8" />
                <span className="ml-2 text-xl font-bold">BRAND</span>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-gray-700 hover:text-black">Men</a>
              <a href="#" className="text-gray-700 hover:text-black">Women</a>
              <a href="#" className="text-gray-700 hover:text-black">Accessories</a>
              <a href="#" className="text-gray-700 hover:text-black">Sale</a>
            </div>
            <div className="flex items-center space-x-4">
              <Search className="h-6 w-6 text-gray-400 hover:text-black cursor-pointer" />
              <User className="h-6 w-6 text-gray-400 hover:text-black cursor-pointer" />
              <Heart className="h-6 w-6 text-gray-400 hover:text-black cursor-pointer" />
              <ShoppingCart className="h-6 w-6 text-gray-400 hover:text-black cursor-pointer" />
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative">
        <div className="absolute inset-0">
          <img
            className="w-full h-[600px] object-cover"
            src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?auto=format&fit=crop&q=80&w=2000"
            alt="Hero"
          />
          <div className="absolute inset-0 bg-black opacity-40"></div>
        </div>
        <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            New Season Collection
          </h1>
          <p className="mt-6 text-xl text-white max-w-3xl">
            Discover our latest arrivals featuring premium materials and timeless designs.
          </p>
          <div className="mt-10">
            <a
              href="#"
              className="inline-block bg-white px-8 py-3 text-base font-medium text-black hover:bg-gray-100"
            >
              Shop Now
            </a>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-2xl font-bold mb-8">Shop by Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories.map((category) => (
            <div key={category.name} className="relative group cursor-pointer">
              <div className="relative h-80 w-full overflow-hidden">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black opacity-20 group-hover:opacity-30 transition-opacity"></div>
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <h3 className="text-2xl font-bold text-white">{category.name}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Featured Products */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-2xl font-bold mb-8">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <div key={product.id} className="group">
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-96 object-cover object-center"
                />
                <button className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-white px-6 py-2 text-sm font-medium text-black opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  Add to Cart
                </button>
              </div>
              <div className="mt-4">
                <h3 className="text-sm font-medium">{product.name}</h3>
                <p className="mt-1 text-sm font-medium text-gray-900">${product.price}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Newsletter */}
      <div className="bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-2">Subscribe to our newsletter</h2>
            <p className="text-gray-600 mb-6">Stay updated with our latest collections and exclusive offers.</p>
            <div className="max-w-md mx-auto">
              <div className="flex gap-2">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-black"
                />
                <button className="px-6 py-2 bg-black text-white hover:bg-gray-800">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-sm font-bold mb-4">About</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-600 hover:text-black">Our Story</a></li>
                <li><a href="#" className="text-gray-600 hover:text-black">Careers</a></li>
                <li><a href="#" className="text-gray-600 hover:text-black">Press</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-bold mb-4">Help</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-600 hover:text-black">Shipping</a></li>
                <li><a href="#" className="text-gray-600 hover:text-black">Returns</a></li>
                <li><a href="#" className="text-gray-600 hover:text-black">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-bold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-600 hover:text-black">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-600 hover:text-black">Terms of Service</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-bold mb-4">Follow Us</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-600 hover:text-black">Instagram</a></li>
                <li><a href="#" className="text-gray-600 hover:text-black">Twitter</a></li>
                <li><a href="#" className="text-gray-600 hover:text-black">Facebook</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t">
            <p className="text-center text-gray-600">&copy; 2024 BRAND. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;